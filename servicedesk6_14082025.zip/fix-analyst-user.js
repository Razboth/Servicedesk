const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function fixAnalystUser() {
  try {
    console.log('🔧 Fixing analyst user access...\n');

    // First, find the SECURITY_OPS support group
    const secOpsGroup = await prisma.supportGroup.findUnique({
      where: { code: 'SECURITY_OPS' }
    });

    if (!secOpsGroup) {
      console.log('❌ SECURITY_OPS support group not found!');
      console.log('Run: npm run db:seed:soc');
      return;
    }

    // Find users that might be security analysts
    const analystUsers = await prisma.user.findMany({
      where: {
        OR: [
          { email: { contains: 'analyst' } },
          { role: 'SECURITY_ANALYST' }
        ]
      },
      include: {
        supportGroup: true
      }
    });

    console.log(`Found ${analystUsers.length} analyst user(s):\n`);

    for (const user of analystUsers) {
      console.log(`📧 ${user.email}`);
      console.log(`   Name: ${user.name}`);
      console.log(`   Role: ${user.role}`);
      console.log(`   Support Group: ${user.supportGroup?.name || 'None'}`);
      
      // Update if needed
      if (user.role === 'SECURITY_ANALYST' && !user.supportGroupId) {
        await prisma.user.update({
          where: { id: user.id },
          data: { supportGroupId: secOpsGroup.id }
        });
        console.log(`   ✅ Added to SECURITY_OPS support group`);
      } else if (user.role === 'SECURITY_ANALYST' && user.supportGroupId === secOpsGroup.id) {
        console.log(`   ✅ Already correctly configured`);
      }
      
      console.log('');
    }

    // Also create a test security analyst if none exist
    const securityAnalyst = await prisma.user.findFirst({
      where: { email: 'security.analyst@banksulutgo.co.id' }
    });

    if (!securityAnalyst) {
      console.log('Creating test security analyst user...');
      const bcrypt = await import('bcryptjs');
      
      await prisma.user.create({
        data: {
          email: 'security.analyst@banksulutgo.co.id',
          name: 'Security Analyst',
          password: await bcrypt.default.hash('password123', 10),
          role: 'SECURITY_ANALYST',
          supportGroupId: secOpsGroup.id,
          isActive: true
        }
      });
      
      console.log('✅ Created security.analyst@banksulutgo.co.id (password: password123)');
    }

    console.log('\n✅ Done! Security analysts should now see the SOC Parser menu.');

  } catch (error) {
    console.error('Error:', error);
  } finally {
    await prisma.$disconnect();
  }
}

fixAnalystUser();