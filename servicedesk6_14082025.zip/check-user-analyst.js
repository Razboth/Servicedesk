const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function checkUserAnalyst() {
  try {
    // Find the user_analyst user
    const user = await prisma.user.findFirst({
      where: {
        OR: [
          { email: { contains: 'user_analyst' } },
          { name: { contains: 'User Analyst' } }
        ]
      },
      include: {
        supportGroup: true,
        branch: true
      }
    });

    if (user) {
      console.log('\n👤 User Analyst Details:');
      console.log('------------------------');
      console.log('ID:', user.id);
      console.log('Email:', user.email);
      console.log('Name:', user.name);
      console.log('Role:', user.role);
      console.log('Branch:', user.branch?.name || 'None');
      console.log('Support Group:', user.supportGroup?.name || 'None');
      console.log('Support Group Code:', user.supportGroup?.code || 'None');
      console.log('Active:', user.isActive);
      
      // Check what the user should see
      console.log('\n🔍 Menu Visibility:');
      console.log('------------------------');
      const canSeeSocParser = user.role === 'SECURITY_ANALYST' || user.supportGroup?.code === 'SECURITY_OPS';
      console.log('Should see SOC Parser:', canSeeSocParser);
      console.log('Reason:', user.role === 'SECURITY_ANALYST' ? 'Has SECURITY_ANALYST role' : 
                           user.supportGroup?.code === 'SECURITY_OPS' ? 'In SECURITY_OPS support group' : 
                           'No access');
    } else {
      console.log('❌ User with email/name containing "user_analyst" not found');
      
      // List all users to help find the right one
      console.log('\n📋 All users in system:');
      const allUsers = await prisma.user.findMany({
        select: {
          email: true,
          name: true,
          role: true
        },
        orderBy: { email: 'asc' }
      });
      
      allUsers.forEach(u => {
        console.log(`- ${u.email} (${u.name}) - Role: ${u.role}`);
      });
    }

  } catch (error) {
    console.error('Error:', error);
  } finally {
    await prisma.$disconnect();
  }
}

checkUserAnalyst();