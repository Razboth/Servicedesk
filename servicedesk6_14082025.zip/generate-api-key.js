const crypto = require('crypto');

// Generate a secure API key
function generateApiKey() {
  const prefix = 'sk_live_';
  const randomPart = crypto.randomBytes(32).toString('hex');
  return `${prefix}${randomPart}`;
}

// Generate and display the API key
console.log('\n🔑 Generating SOC API Key...\n');

const apiKey = generateApiKey();

console.log('======================== SOC API KEY ========================');
console.log('');
console.log('API Key (save this securely, it won\'t be shown again):');
console.log(`  ${apiKey}`);
console.log('');
console.log('To use this API key:');
console.log('');
console.log('1. Add to your .env file:');
console.log(`   SOC_API_KEY=${apiKey}`);
console.log('');
console.log('2. Or use in API requests:');
console.log('   Authorization: Bearer ' + apiKey);
console.log('');
console.log('3. Test with curl:');
console.log(`   curl -X POST http://localhost:3000/api/soc/parse-and-create \\`);
console.log(`     -H "Authorization: Bearer ${apiKey}" \\`);
console.log('     -H "Content-Type: application/json" \\');
console.log('     -d \'{"text": "SOC notification content..."}\'');
console.log('');
console.log('4. Example with real SOC data:');
console.log('   curl -X POST http://localhost:3000/api/soc/parse-and-create \\');
console.log(`     -H "Authorization: Bearer ${apiKey}" \\`);
console.log('     -H "Content-Type: application/json" \\');
console.log('     -d @soc-notification.json');
console.log('');
console.log('=============================================================\n');