import NextAuth from 'next-auth'
import Credentials from 'next-auth/providers/credentials'
import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

// Account lockout configuration
const MAX_LOGIN_ATTEMPTS = 5
const LOCKOUT_DURATION = 30 * 60 * 1000 // 30 minutes in milliseconds

// Helper function to check if account is locked
async function isAccountLocked(email: string): Promise<boolean> {
  const user = await prisma.user.findUnique({
    where: { email },
    select: { loginAttempts: true, lockedAt: true }
  })

  if (!user || !user.lockedAt) return false

  // Check if lockout period has expired
  const lockoutExpired = new Date().getTime() - new Date(user.lockedAt).getTime() > LOCKOUT_DURATION
  
  if (lockoutExpired) {
    // Reset lockout if expired
    await prisma.user.update({
      where: { email },
      data: {
        loginAttempts: 0,
        lockedAt: null,
        lastLoginAttempt: null
      }
    })
    return false
  }

  return user.loginAttempts >= MAX_LOGIN_ATTEMPTS
}

// Helper function to record login attempt
async function recordLoginAttempt(email: string, success: boolean, ipAddress?: string, userAgent?: string): Promise<void> {
  const user = await prisma.user.findUnique({
    where: { email },
    select: { id: true, loginAttempts: true }
  })

  if (!user) {
    // Record attempt even for non-existent users
    await prisma.loginAttempt.create({
      data: {
        email,
        success: false,
        ipAddress,
        userAgent
      }
    })
    return
  }

  const newAttempts = success ? 0 : user.loginAttempts + 1
  const shouldLock = !success && newAttempts >= MAX_LOGIN_ATTEMPTS
  
  // Update user login tracking
  await prisma.user.update({
    where: { email },
    data: {
      loginAttempts: newAttempts,
      lastLoginAttempt: new Date(),
      lockedAt: shouldLock ? new Date() : undefined,
      lastActivity: success ? new Date() : undefined
    }
  })

  // Record in audit log
  await prisma.loginAttempt.create({
    data: {
      email,
      success,
      ipAddress,
      userAgent,
      lockTriggered: shouldLock
    }
  })
}

const authOptions = {
  // Use secure cookies in production
  cookies: {
    sessionToken: {
      name: process.env.NODE_ENV === 'production' ? '__Secure-next-auth.session-token' : 'next-auth.session-token',
      options: {
        httpOnly: true,
        sameSite: 'strict' as const,
        path: '/',
        secure: process.env.NODE_ENV === 'production'
      }
    }
  },
  providers: [
    Credentials({
      name: 'credentials',
      credentials: {
        email: { label: 'Email', type: 'email' },
        password: { label: 'Password', type: 'password' }
      },
      async authorize(credentials, req) {
        if (!credentials?.email || !credentials?.password) {
          return null
        }

        const email = credentials.email as string
        const password = credentials.password as string

        // Extract IP and User Agent from request headers
        const ipAddress = req?.headers?.['x-forwarded-for'] || 
                         req?.headers?.['x-real-ip'] || 
                         req?.connection?.remoteAddress
        const userAgent = req?.headers?.['user-agent']

        try {
          // Check if account is locked
          if (await isAccountLocked(email)) {
            await recordLoginAttempt(email, false, ipAddress, userAgent)
            throw new Error('ACCOUNT_LOCKED')
          }

          // Find user in database
          const user = await prisma.user.findUnique({
            where: {
              email: email,
              isActive: true
            },
            include: {
              branch: true
            }
          })

          if (!user || !user.password) {
            await recordLoginAttempt(email, false, ipAddress, userAgent)
            return null
          }

          // Verify password
          const isPasswordValid = await bcrypt.compare(password, user.password)

          if (!isPasswordValid) {
            await recordLoginAttempt(email, false, ipAddress, userAgent)
            return null
          }

          // Successful login - record attempt and update activity
          await recordLoginAttempt(email, true, ipAddress, userAgent)

          // Get user with support group
          const userWithSupportGroup = await prisma.user.findUnique({
            where: { id: user.id },
            include: {
              supportGroup: true
            }
          })

          return {
            id: user.id,
            email: user.email,
            name: user.name,
            role: user.role,
            branchId: user.branchId,
            branchName: user.branch?.name,
            supportGroupId: userWithSupportGroup?.supportGroupId,
            supportGroupCode: userWithSupportGroup?.supportGroup?.code
          }
        } catch (error) {
          if (error.message === 'ACCOUNT_LOCKED') {
            throw new Error('Your account has been locked due to too many failed login attempts. Please contact your administrator.')
          }
          console.error('Auth error:', error)
          return null
        }
      }
    })
  ],
  session: {
    strategy: 'jwt' as const
  },
  callbacks: {
    async jwt({ token, user }: any) {
      if (user) {
        token.role = user.role;
        token.branchId = user.branchId;
        token.branchName = user.branchName;
        token.supportGroupId = user.supportGroupId;
        token.supportGroupCode = user.supportGroupCode;
      }
      return token;
    },
    async session({ session, token }: any) {
      if (token) {
        session.user.id = token.sub!;
        session.user.role = token.role as string;
        session.user.branchId = token.branchId as string | null;
        session.user.branchName = token.branchName as string | null;
        session.user.supportGroupId = token.supportGroupId as string | null;
        session.user.supportGroupCode = token.supportGroupCode as string | null;
      }
      return session;
    }
  },
  pages: {
    signIn: '/auth/signin',
    error: '/auth/error',
  },
  // Dynamic URL configuration to handle different hosts (IP addresses, domains)
  trustHost: true,
}

export const { handlers, auth, signIn, signOut } = NextAuth(authOptions)