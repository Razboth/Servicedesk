import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { Providers } from '@/components/providers/session-provider'
import { SidebarProvider } from '@/components/providers/sidebar-provider'
import { SidebarLayout } from '@/components/navigation/sidebar-layout'
import { Toaster } from 'sonner'
import IdleTimer from '@/components/auth/idle-timer'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Bank SulutGo ServiceDesk',
  description: 'IT Service Management Portal for Bank SulutGo',
  keywords: ['servicedesk', 'ITSM', 'Bank SulutGo', 'IT support'],
  authors: [{ name: 'Bank SulutGo IT Team' }],
  robots: 'noindex, nofollow',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <Providers>
          <SidebarProvider>
            <SidebarLayout>
              {children}
            </SidebarLayout>
          </SidebarProvider>
          <IdleTimer />
          <Toaster />
        </Providers>
      </body>
    </html>
  )
}