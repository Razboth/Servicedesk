import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function GET(request: NextRequest) {
  try {
    const session = await auth();
    
    if (!session || !['MANAGER', 'ADMIN', 'TECHNICIAN'].includes(session.user.role)) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    // Get user's branch if not admin
    let branchId: string | undefined;
    if (session.user.role !== 'ADMIN') {
      const user = await prisma.user.findUnique({
        where: { id: session.user.id },
        select: { branchId: true }
      });
      branchId = user?.branchId || undefined;
    }

    // Fetch ATMs with their status
    const atms = await prisma.aTM.findMany({
      where: branchId ? { branchId } : {},
      include: {
        branch: {
          select: {
            id: true,
            name: true,
            code: true
          }
        },
        incidents: {
          where: {
            createdAt: {
              gte: new Date(Date.now() - 24 * 60 * 60 * 1000) // Last 24 hours
            }
          }
        }
      }
    });

    // Fetch active tickets for each ATM
    const atmCodes = atms.map(atm => atm.code);
    const activeTickets = await prisma.ticket.findMany({
      where: {
        OR: atmCodes.map(code => ({
          OR: [
            { description: { contains: code, mode: 'insensitive' } },
            { title: { contains: code, mode: 'insensitive' } }
          ]
        })),
        status: {
          in: ['OPEN', 'IN_PROGRESS', 'PENDING_APPROVAL']
        }
      },
      select: {
        id: true,
        title: true,
        description: true
      }
    });

    // Transform ATM data with status information
    const atmStatus = atms.map(atm => {
      // Count active tickets for this ATM
      const atmActiveTickets = activeTickets.filter(ticket => 
        ticket.title.toLowerCase().includes(atm.code.toLowerCase()) ||
        ticket.description.toLowerCase().includes(atm.code.toLowerCase())
      ).length;

      // Simulate ATM status based on incidents and other factors
      let status: 'OPERATIONAL' | 'WARNING' | 'DOWN' | 'MAINTENANCE' = 'OPERATIONAL';
      let uptime = 99.5;
      let cashLevel = Math.floor(Math.random() * 80) + 20; // Random 20-100
      let paperLevel = Math.floor(Math.random() * 80) + 20; // Random 20-100

      // Determine status based on incidents
      if (atm.incidents.length > 0) {
        const criticalIncidents = atm.incidents.filter(i => 
          i.severity === 'CRITICAL' || i.severity === 'HIGH'
        );
        
        if (criticalIncidents.length > 0) {
          status = 'DOWN';
          uptime = 85 + Math.random() * 10;
        } else if (atm.incidents.length >= 2) {
          status = 'WARNING';
          uptime = 90 + Math.random() * 8;
        }
      }

      // Check if in maintenance based on recent changes
      if (atm.lastMaintenanceDate && 
          new Date(atm.lastMaintenanceDate) > new Date(Date.now() - 2 * 60 * 60 * 1000)) {
        status = 'MAINTENANCE';
      }

      // Simulate low resource warnings
      if (cashLevel < 30 || paperLevel < 30) {
        if (status === 'OPERATIONAL') {
          status = 'WARNING';
        }
      }

      return {
        id: atm.id,
        code: atm.code,
        location: atm.location,
        status,
        lastPing: new Date().toISOString(), // Simulate last ping time
        uptime: parseFloat(uptime.toFixed(2)),
        cashLevel,
        paperLevel,
        branch: atm.branch,
        recentIncidents: atm.incidents.length,
        activeTickets: atmActiveTickets
      };
    });

    return NextResponse.json({ atms: atmStatus });
  } catch (error) {
    console.error('Error fetching ATM status:', error);
    return NextResponse.json(
      { error: 'Failed to fetch ATM status' },
      { status: 500 }
    );
  }
}