'use client';

import { useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Textarea } from '@/components/ui/textarea';
import { Shield, AlertTriangle, FileText, Loader2 } from 'lucide-react';

export default function SOCParserPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [socText, setSocText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState('');

  // Check authorization
  if (status === 'loading') {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (!session || (!['SECURITY_ANALYST', 'ADMIN'].includes(session.user.role) && session.user.supportGroupCode !== 'SECURITY_OPS')) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Alert className="bg-red-50 border-red-200">
          <AlertTriangle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-800">
            Access denied. This page is only available to Security Analysts or members of the Security Operations Center.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  const handleParse = async () => {
    if (!socText.trim()) {
      setError('Please paste the SOC notification text');
      return;
    }

    setIsProcessing(true);
    setError('');
    setResult(null);

    try {
      const response = await fetch('/api/soc/parse-and-create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ text: socText })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to create SOC ticket');
      }

      setResult(data);
      
      // Clear the text area on success
      setSocText('');

      // Redirect to the created ticket after 3 seconds
      if (data.ticket?.id) {
        setTimeout(() => {
          router.push(`/tickets/${data.ticket.id}`);
        }, 3000);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setIsProcessing(false);
    }
  };

  const sampleText = `Dear Team IT,
SOC Notification Alert!
Date                                : 08/04/2025 12:50:33 pm
Severity                          : High
First Action Needed        : Validasi
Case ID LR                       : -
Ultima ID                       : ABC-DEF-082025-11704
Incident Type                   : ENDS: LIN: PE-TA0004: Sudo Command Executed: Log: Success
IP / Host Origin               : -
User Origin                      : -
IP / Host Impacted           : HOST-IMPACTED
User Impacted                 : -
Log Source                      : -
Status Tiket                      : New
Port                                  : -
Classification                   : Activity
URL                                  : -
File_Proses                       : sudo
File_Path                           : -
Action                              : -
Deskripsi:
Team SOC menemukan alarm ENDS: LIN: PE-TA0004: Sudo Command Executed: Log: Success pada log source Linux.
Event tersebut terjadi karena terdeteksinya adanya aktivitas sudo command executed pada [user1] dan [-] dengan [server1] menggunakan [sudo] pada [/usr/bin/su].
pada perintah /usr/bin/su digunakan untuk beralih (switch) ke pengguna lain yang biasanya untuk memperoleh akses lebih tinggi  seperti root (administrator).
Rekomendasi:
1. Melakukan pengecekan dan validasi terkait aktivitas pada IP/user omsagent legitimate atau tidak.
2. Membatasi atau limitasi user untuk melakukan perintah command sudo menggunakan user root.
3. Gunakan password dengan karakter unik. Password yang terdiri dari karakter, termasuk huruf, angka, dan simbol.
4. Aktifkan verifikasi dua faktor (2FA). 2FA menambahkan lapisan keamanan tambahan untuk memasukkan kode yang dikirim ke perangkat.
Terima kasih.
Salam,
SOC Team`;

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2">
          <Shield className="h-6 w-6 text-red-600" />
          <h1 className="text-2xl font-bold">SOC Notification Parser</h1>
        </div>
        <p className="text-gray-600">
          Parse SOC email notifications and automatically create security incident tickets
        </p>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Parse SOC Notification</CardTitle>
          <CardDescription>
            Paste the SOC notification email content below. The system will automatically extract all fields and create a ticket.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Textarea
              placeholder="Paste SOC notification text here..."
              value={socText}
              onChange={(e) => setSocText(e.target.value)}
              className="min-h-[400px] font-mono text-sm"
            />
          </div>

          {error && (
            <Alert className="bg-red-50 border-red-200">
              <AlertTriangle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800">{error}</AlertDescription>
            </Alert>
          )}

          {result && (
            <Alert className="bg-green-50 border-green-200">
              <FileText className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-800">
                <div className="space-y-1">
                  <p className="font-medium">Ticket created successfully!</p>
                  <p>Ticket Number: {result.ticket.ticketNumber}</p>
                  <p>Priority: {result.ticket.priority}</p>
                  {result.ticket.assignedTo && (
                    <p>Assigned to: {result.ticket.assignedTo.name}</p>
                  )}
                  <p className="text-sm mt-2">Redirecting to ticket details...</p>
                </div>
              </AlertDescription>
            </Alert>
          )}

          <div className="flex justify-between items-center">
            <Button
              variant="outline"
              onClick={() => setSocText(sampleText)}
              disabled={isProcessing}
            >
              Load Sample
            </Button>
            
            <Button
              onClick={handleParse}
              disabled={isProcessing || !socText.trim()}
              className="bg-red-600 hover:bg-red-700"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <Shield className="mr-2 h-4 w-4" />
                  Create SOC Ticket
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>API Integration</CardTitle>
          <CardDescription>
            External SOC tools can integrate using the API endpoint
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="bg-gray-50 p-4 rounded-lg">
            <p className="font-mono text-sm mb-2">POST /api/soc/parse-and-create</p>
            <p className="text-sm text-gray-600 mb-2">Headers:</p>
            <pre className="bg-gray-100 p-2 rounded text-xs overflow-x-auto">
{`Authorization: Bearer YOUR_API_KEY
Content-Type: application/json`}
            </pre>
            <p className="text-sm text-gray-600 mb-2 mt-2">Body:</p>
            <pre className="bg-gray-100 p-2 rounded text-xs overflow-x-auto">
{`{
  "text": "SOC notification content..."
}`}
            </pre>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}