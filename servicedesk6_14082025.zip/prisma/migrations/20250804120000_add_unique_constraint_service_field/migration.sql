-- CreateIndex
CREATE UNIQUE INDEX "ServiceField_serviceId_name_key" ON "service_fields"("serviceId", "name");